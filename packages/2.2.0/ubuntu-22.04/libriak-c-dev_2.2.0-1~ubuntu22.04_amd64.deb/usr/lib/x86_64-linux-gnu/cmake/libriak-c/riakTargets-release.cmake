#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "riak::riak" for configuration "Release"
set_property(TARGET riak::riak APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(riak::riak PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "json-c::json-c"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libriak-c.so.2.2.0"
  IMPORTED_SONAME_RELEASE "libriak-c.so.2"
  )

list(APPEND _IMPORT_CHECK_TARGETS riak::riak )
list(APPEND _IMPORT_CHECK_FILES_FOR_riak::riak "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libriak-c.so.2.2.0" )

# Import target "riak::riak_static" for configuration "Release"
set_property(TARGET riak::riak_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(riak::riak_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libriak-c.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS riak::riak_static )
list(APPEND _IMPORT_CHECK_FILES_FOR_riak::riak_static "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libriak-c.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
